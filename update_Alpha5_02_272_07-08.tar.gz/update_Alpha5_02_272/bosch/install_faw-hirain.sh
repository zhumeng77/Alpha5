#!/bin/sh

###################################################################
# Install script for TDR on HiRain T-Box
#
# This script is intended to only run once
###################################################################

/usr/rmu/bin/installer_linux -v  | grep installer_linux | cut -d " " -f 3  > /usr/share/Delta_Version

# FAW-15 TDR file structure on T-Boxes 
# Make the file system on the T-Box appear where we expect it to be 
if [ -f /media/bosch/MOUNTED ]; then
	echo Already mounted /media/bosch
else
    mkdir -p /media/bosch
    mount -v  --rbind /extdata/media/bosch /media/bosch
    touch /media/bosch/MOUNTED
fi


###################################################################
# Start the Bosch DBus
###################################################################

chmod 4754 /usr/lib/dbus/dbus-daemon-launch-helper
chown root:messagebus  /usr/lib/dbus/dbus-daemon-launch-helper

# DBus
mkdir -p /var/run/dbus || true
adduser messagebus --home /var/lib/dbus || true
dbus-daemon --system || true
