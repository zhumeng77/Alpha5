/home/root/Bosch/Install/tidy_faw.sh

######################## burn image start #############################
echo "burning image starting ..."
#----------------------- burn uboot start ----------------------------#
#clear u-boot arg
#dd if=/dev/zero of=/dev/mmcblk2 bs=1K seek=384 conv=fsync count=129
#access boot partition 1
#echo 0 > /sys/block/mmcblk2boot0/force_ro
#write U-boot to sd card
#dd if=./image/u-boot.imx of=/dev/mmcblk2boot0 bs=512 seek=2
#re-enable read-only access
#echo 1 > /sys/block/mmcblk2boot0/force_ro
#enable boot partion 1 to boot
#chmod +x ./mmc
#./mmc bootpart enable 1 1 /dev/mmcblk2
#----------------------- burn uboot end ------------------------------#

#----------------------- burn kernel start ---------------------------#
#write kernel image_bak to eMMC
dd if=./image/uImage of=/dev/mmcblk2 bs=1M seek=1 conv=fsync
#write kernel image to eMMC
dd if=./image/uImage of=/dev/mmcblk2 bs=1M seek=31 conv=fsync
#----------------------- burn kernel end -----------------------------#

#----------------------- burn ramfs start ----------------------------#
#write rootfs ramfs_bak to eMMC
dd if=./image/initramfs.cpio.gz.rd of=/dev/mmcblk2 bs=1M seek=5 conv=fsync
#write rootfs ramfs to eMMC
dd if=./image/initramfs.cpio.gz.rd of=/dev/mmcblk2 bs=1M seek=35 conv=fsync
#----------------------- burn ramfs end ------------------------------#

#----------------------- burn dtb start ------------------------------#
#write dtb FDT_BAK to eMMC
dd if=./image/imx6dl-bluez.dtb of=/dev/mmcblk2 bs=1M seek=30 conv=fsync
#write dtb FDT to eMMC
dd if=./image/imx6dl-bluez.dtb of=/dev/mmcblk2 bs=1M seek=60 conv=fsync
#----------------------- burn dtb end --------------------------------#
echo "burning image done."
########################  burn image end ##############################



####################### update disk start #############################
echo "update disk starting ..."
#---------------- update data partition start ------------------------#
tar xf ./disk/data.tgz -C /data/
#----------------  update data partition end  ------------------------#

#--------------- update extdata partition start ----------------------#
tar xf ./disk/extdata.tgz -C /extdata/
#---------------  update extdata partition end  ----------------------#

#--------------- update cache partition start ------------------------#
tar xf ./disk/cache.tgz -C /cache/
#---------------  update cache partition end  ------------------------#

#----------------- update rmu partition start ------------------------#
#tar xf ./disk/rmu.tgz -C /usr/rmu/
#-----------------  update rmu partition end  ------------------------#
echo "update disk done."
####################### update disk end  ##############################



####################### update libs start #############################
echo "update libs starting ..."
tar xf ./libs/jansson-2.10-package.tar.gz -C /data/usr/
tar xf ./libs/liblzma-package.tar.gz -C /data/usr/
tar xf ./libs/libprce-8.36.tar.gz -C /data/usr/
tar xf ./libs/libstdc-package.tar.gz -C /data/usr/
tar xf ./libs/libunwind-package.tar.gz -C /data/usr/
tar xf ./libs/libzip-1.3.2-package.tar.gz -C /data/usr/
tar xf ./libs/log4cplus-1.2.0-package.tar.gz -C /data/usr/
tar xf ./libs/mimetic-0.9.8-package.tar.gz -C /data/usr/
tar xf ./libs/protobuf-2.6.1.tar.gz -C /data/usr/
tar xf ./libs/lua-filesystem-1.6.3-r1.tar.gz -C /data/
echo "update libs done."
####################### update libs end  ##############################



##################### update bosch TDR start ##########################
echo "update bosch TDR starting ..."
tar xf ./bosch/HiRain-release_02_272.tar.gz -C /
tar xf ./bosch/ota_api.tar.gz -C /
cp ./bosch/install_faw-hirain.sh /home/root/Bosch/
cp ./bosch/installer_linux /usr/rmu/bin
chmod +x /usr/rmu/bin/installer_linux
echo "update bosch TDR done."
#####################  update bosch TDR end  ###########################

sync

echo "update done"
